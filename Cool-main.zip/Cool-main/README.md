
> ⚠️ This project is currently a work in progress and is still unfinished. While I'm actively working on it and making progress, there may still be bugs and incomplete features. ⚠️

# Supported Stuff

* 1080p 60fps

* Sound

* Windows apps (wine)

* Browsering (Brave and Firefox included!)

* Home Persistance (You keep your files!)

# Use
you obviously need a github account to use this

it's very simple to install, there is a pseudo-graphical installer.

first Remember to star the repo (optional but appreciated)

after start a new codespace https://github.com/codespaces/new
to install just copy and paste this command in your codespace terminal
```
curl -O https://git.Cool.dev/sdedew/DesktopOnCodespaces/raw/branch/main/install.sh
chmod +x install.sh
./install.sh
